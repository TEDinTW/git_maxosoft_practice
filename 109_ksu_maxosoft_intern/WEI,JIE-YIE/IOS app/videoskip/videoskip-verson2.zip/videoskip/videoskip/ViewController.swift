//
//  ViewController.swift
//  videoskip
//
//  Created by Leaf on 2021/6/29.
//

import UIKit
import AVKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        videoskip.translatesAutoresizingMaskIntoConstraints = false
        videoskip.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        videoskip.heightAnchor.constraint(equalTo: view.widthAnchor, multiplier: 16/9).isActive = true
        videoskip.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        videoskip.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        view.backgroundColor = .black
    }

   
    
}

