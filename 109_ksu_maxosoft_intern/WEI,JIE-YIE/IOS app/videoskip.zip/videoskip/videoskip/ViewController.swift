//
//  ViewController.swift
//  videoskip
//
//  Created by Leaf on 2021/6/29.
//

import UIKit
import AVKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBSegueAction func showvideo(_ coder: NSCoder) -> AVPlayerViewController? {
        let controller = AVPlayerViewController(coder:coder)
        let url = Bundle.main.url(forResource: "測試", withExtension: "mp4")
        print (url)
        controller?.player = AVPlayer(url:url!)
        controller?.player?.play()
        return controller
    }
    
}

